package com.capgemini.java;
//A1. Print the following patterns on screen with appropriate logic

import javax.print.attribute.SetOfIntegerSyntax;

public class AssignmentA1 {
	public static void main(String[] args) {
	int i,j;
		for ( i=1;i<=6;i++) {
			
			for( j=1;j<=6;j++) {
			
				{
					System.out.println(j +"  ");
				}
				{
					System.out.println("  "); 
				}
			}
		}
	}
}
		
		
			
		
	


