package com.capgemini.java;
//A3. Print the following patterns on screen with appropriate logic
public class AssignmentA3 {
	public static void main(String[] args) {
		int i, j, row=6;
		for(i=0;i<row;i++);
		{
			for (j=0; j<=i;j++);
			
			{
				System.out.println("* ");
				
				{
					System.out.println();
				}
			}
		}
		
		
	}
}
