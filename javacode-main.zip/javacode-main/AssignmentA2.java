package com.capgemini.java;
//A2. Print the following patterns on screen with appropriate logic

public class AssignmentA2 {
	public static void main(String[] args) {

			
		for (int i=7;i>0;i--) {
			
			for (int j=0; j<i;j++) {
				
				System.out.println(j+1);
			}
			
			System.out.println("");
			}
		}
	}

		
		


